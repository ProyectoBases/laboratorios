----------XPOBLAR----------

DELETE FROM forma;

DELETE FROM tienPrioridad;

DELETE FROM posee;

DELETE FROM metodologia;

DELETE FROM avance;

DELETE FROM curso;

DELETE FROM planFormacion;

DELETE FROM habilidad;

DELETE FROM candidato;