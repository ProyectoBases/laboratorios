----------XTABLAS----------

DROP TABLE forma;

DROP TABLE tienPrioridad;

DROP TABLE posee;

DROP TABLE metodologia;

DROP TABLE avance;

DROP TABLE curso;

DROP TABLE planFormacion;

DROP TABLE habilidad;

DROP TABLE candidato;
