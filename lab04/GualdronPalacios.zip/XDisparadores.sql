----------XDisparadores----------

DROP TRIGGER AD_planFormacion_numero; 
DROP TRIGGER AD_planFormacion_fecha; 
DROP TRIGGER AD_planFormacion_estado; 
DROP TRIGGER AD_planFormacion_planFormacion; 
DROP TRIGGER AD_planFormacion_evaluador; 
DROP TRIGGER AD_planFormacion_estado_;
DROP TRIGGER AD_habilidad;
DROP TRIGGER AD_planFormacion_hab; 
DROP TRIGGER AD_habilidad_curso; 
DROP TRIGGER MO_planFormacion; 
DROP TRIGGER del_planFormacion; 
DROP TRIGGER AD_avanceNumero;
DROP TRIGGER AD_avanceFecha;
DROP TRIGGER AD_avanceInscripcion;
DROP TRIGGER AD_curso_cerrado;
DROP TRIGGER AD_cursoHabilidad; 